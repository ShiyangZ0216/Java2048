package finalPro;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;

public class GameClient {
	DataOutputStream toServer = null;
	DataInputStream fromServer = null;
	Socket socket = null;
	Frame2048 Game = new Frame2048();
	
	public GameClient() {
		try {
			socket = new Socket("localhost", 8000);
			fromServer = new DataInputStream(socket.getInputStream());
			toServer = new DataOutputStream(socket.getOutputStream());
		}
		catch (IOException ex) {
			System.out.println("Socket creating failed");
	    }
		
		ManageConnection();
		
	}
	
	private void ManageConnection() {
		class SaveItemListener implements ActionListener {
	    	public void actionPerformed(ActionEvent e){
	    		Game.G.GameScoreBuffer = Game.G.GameScore;
	    		try {
	    			//toServer.writeBytes(Game.Player);
	    			for(int i = 0; i < 4; i++) {
			        	for(int j = 0; j < 4; j++) {
			        		toServer.writeInt(Game.G.numBuffers[i][j]);
			        	}
			        }
	    			//toServer.writeInt(Game.G.GameScore);
	    			toServer.flush();
	    		}
	    		catch (IOException ex) {
	    			System.out.println("Data writing failed");
	    	    }
	    		
	    		try {
	    			for(int i = 0; i < 4; i++) {
	    	        	for(int j = 0; j < 4; j++) {
	    	        		Game.G.loadBuffers[i][j] = fromServer.readInt();
	    	        		System.out.println("saved num: " + Game.G.loadBuffers[i][j]);
	    	        	}
	    	        }
	    		}
	    		catch (IOException ex) {
	    			System.out.println("Data reading failed");
	    	    }
	    	}
	    }
		ActionListener Slistener = new SaveItemListener();
	    Game.SaveItem.addActionListener(Slistener);
	    
	    class LoadItemListener implements ActionListener {
	    	public void actionPerformed(ActionEvent e){
	    		Game.G.GameScore = Game.G.GameScoreBuffer;
	    		for(int i = 0; i < 4; i++) {
    	        	for(int j = 0; j < 4; j++) {
    	        		Game.G.numBuffers[i][j] = Game.G.loadBuffers[i][j];
    	        		System.out.println("Loaded num: " + Game.G.numBuffers[i][j]);
    	        	}
    	        }
	    		Game.BlockVisible();
	    	}
	    }
		ActionListener Llistener = new LoadItemListener();
	    Game.LoadItem.addActionListener(Llistener);
	}
	
	public static void main(String[] args) {
		GameClient GC = new GameClient();
		GC.Game.setVisible(true);
		//Game.StartGame();
		//Game.G.numBuffers = new int[][] {{32,32,4,4},{32,0,2,0},{2,2,2,2},{2,0,0,4}};
	}
	
}
