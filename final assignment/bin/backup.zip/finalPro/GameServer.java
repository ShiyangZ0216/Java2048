package finalPro;

import java.io.*;
import java.net.*;
import java.util.Date;
import javax.swing.*;

public class GameServer extends JFrame implements Runnable {
	private JTextArea remindTable;
	private int clientNo = 0;
	
	public GameServer() {
		remindTable = new JTextArea(10,10);
		JScrollPane sp = new JScrollPane(remindTable);
		this.add(sp);
		this.setTitle("MultiThreadServer");
		this.setSize(400,200);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Thread t = new Thread(this);
		t.start();
	}
	
	public void run() {
		try {
			ServerSocket serverSocket = new ServerSocket(8000);
			remindTable.append("Game Server started !" + '\n');
			
			while (true) {
				Socket socket = serverSocket.accept();
				clientNo++;
				remindTable.append("Starting thread for client " + clientNo + " at " + new Date() + '\n');
				
				InetAddress inetAddress = socket.getInetAddress();
				
				new Thread(new HandleAClient(socket, clientNo)).start();
			}
		}
		catch(IOException e) {
			System.out.println("Server failed to run");
		}
	}
	
	class HandleAClient implements Runnable {
		private Socket socket; // A connected socket
		private int clientNum;
	    
	    /** Construct a thread */
	    public HandleAClient(Socket socket, int clientNum) {
	      this.socket = socket;
	      this.clientNum = clientNum;
	    }
	    
	    public void run() {
	    	try {
	    		DataInputStream input = new DataInputStream(socket.getInputStream());
	    		DataOutputStream output = new DataOutputStream(socket.getOutputStream());

	    		while (true) {
	    			int rec[][] = new int[4][4];
	    			for(int i = 0; i < 4; i++) {
	    				for(int j = 0; j < 4; j++) {
	    					rec[i][j] = input.readInt();
	    					remindTable.append("data received from client: " + rec[i][j] + '\n');
	    				}
	    			}
	    			for(int i = 0; i < 4; i++) {
	    				for(int j = 0; j < 4; j++) {
	    					output.writeInt(rec[i][j]);
	    				}
	    			}
	    		}
	    	}
	    	catch(IOException ex) {
	    		ex.printStackTrace();
	    	}
	    }
	}
	
	public static void main(String[] args) {
		GameServer GS = new GameServer();
		GS.setVisible(true);
	}
}