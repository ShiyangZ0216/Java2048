package finalPro;


import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class NameFrame extends JFrame{
	public JTextField textField = new JTextField(20);
	public JButton confirmName = new JButton("Confirm");
	public int a = 0;
	
	public NameFrame(){
		this.setSize(200,100);
		JPanel AllPanel = new JPanel(new GridLayout(2,1));
		JPanel BPanel = new JPanel();
		BPanel.add(confirmName);
		AllPanel.setSize(50,30);
		AllPanel.add(textField);
		AllPanel.add(BPanel);
		this.add(AllPanel);
	}
}
